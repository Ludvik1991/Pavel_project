# Docker cvičení – Python + MariaDB

## Zadání
Úkol byl udělat dva Docker kontejnery, které spolu budou komunikovat přes vlastní síť.

- MariaDB kontejner – databáze
- Python kontejner – načte data z CSV, upraví je a uloží do databáze

Nakonec se to má spouštět přes `docker-compose.yml`.

---

## Co jsem udělal
Nejdřív jsem vytvořil vlastní Docker síť pomocí:

```bash
docker network create app-network