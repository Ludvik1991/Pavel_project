import csv
import os
import time
from decimal import Decimal

import pymysql


DB_CONFIG = {
    "host": os.getenv("DB_HOST", "mariadb"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "app_user"),
    "password": os.getenv("DB_PASSWORD", "app_pass"),
    "database": os.getenv("DB_NAME", "sales_db"),
    "cursorclass": pymysql.cursors.DictCursor,
    "autocommit": True,
}

CSV_FILE = os.getenv("CSV_FILE", "/app/data/orders.csv")


def wait_for_db(max_attempts=20, delay=3):
    """Počkám, než databáze fakt naběhne. Compose sice pomůže,
    ale tohle je taková moje druhá pojistka, kdyby měla DB líné ráno.
    """
    for attempt in range(1, max_attempts + 1):
        try:
            connection = pymysql.connect(**DB_CONFIG)
            print(f"Databáze jede, připojeno na pokus číslo {attempt}.")
            return connection
        except pymysql.MySQLError as error:
            print(f"Databáze ještě není ready (pokus {attempt}/{max_attempts}): {error}")
            time.sleep(delay)

    raise RuntimeError("Nepodařilo se připojit k databázi ani po více pokusech.")


def transform_row(row):
    """Tady si data trochu učesám, ať do DB neleze bordel."""
    quantity = int(row["quantity"])
    unit_price = Decimal(row["unit_price"])
    total_price = quantity * unit_price

    return (
        row["customer_name"].strip().title(),
        row["city"].strip().title(),
        row["product_name"].strip().capitalize(),
        row["category"].strip().upper(),
        quantity,
        unit_price,
        total_price,
    )


def load_csv_data(file_path):
    transformed_data = []

    with open(file_path, mode="r", encoding="utf-8") as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            transformed_data.append(transform_row(row))

    print(f"Načetl jsem {len(transformed_data)} řádků z CSV.")
    return transformed_data


def save_to_db(connection, data):
    create_table_query = """
    CREATE TABLE IF NOT EXISTS csv_imports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_name VARCHAR(100) NOT NULL,
        city VARCHAR(100) NOT NULL,
        product_name VARCHAR(100) NOT NULL,
        category VARCHAR(50) NOT NULL,
        quantity INT NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        total_price DECIMAL(10,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """

    insert_query = """
    INSERT INTO csv_imports (
        customer_name,
        city,
        product_name,
        category,
        quantity,
        unit_price,
        total_price
    ) VALUES (%s, %s, %s, %s, %s, %s, %s)
    """

    with connection.cursor() as cursor:
        cursor.execute(create_table_query)

        # Ať se to při každém spuštění neduplikuje.
        # Na cvičení je to podle mě praktičtější než tam sypat data pořád dokola.
        cursor.execute("TRUNCATE TABLE csv_imports")

        cursor.executemany(insert_query, data)

    print(f"Do MariaDB jsem uložil {len(data)} řádků.")


def main():
    connection = wait_for_db()
    try:
        data = load_csv_data(CSV_FILE)
        save_to_db(connection, data)
        print("Hotovo, data jsou v databázi.")
    finally:
        connection.close()
        print("Spojení s databází jsem zavřel.")


if __name__ == "__main__":
    main()
